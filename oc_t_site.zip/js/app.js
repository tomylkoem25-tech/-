// Minimal product data and cart functionality
const PRODUCTS = [
  {id:1,title:"Футболка Demo",price:249,desc:"Зручна бавовняна футболка",img:"images/p1.svg"},
  {id:2,title:"Кружка Demo",price:129,desc:"Керамічна кружка 350мл",img:"images/p2.svg"},
  {id:3,title:"Блокнот Demo",price:89,desc:"Еко-блокнот A5",img:"images/p3.svg"},
  {id:4,title:"Сумка Demo",price:199,desc:"Тканинна екосумка",img:"images/p4.svg"}
];

function el(q){return document.querySelector(q)}
function els(q){return document.querySelectorAll(q)}

function renderProductsGrid(targetId) {
  const grid = document.getElementById(targetId);
  if(!grid) return;
  grid.innerHTML = '';
  for(const p of PRODUCTS){
    const card = document.createElement('article');
    card.className = 'card';
    card.innerHTML = `
      <img alt="${p.title}" src="${p.img}">
      <h4>${p.title}</h4>
      <p>${p.desc}</p>
      <div class="price">${p.price.toFixed(2)} грн</div>
      <button data-id="${p.id}" class="add-btn">Додати в кошик</button>
    `;
    grid.appendChild(card);
  }
}

function populatePreview(){
  renderProductsGrid('preview-grid');
  renderProductsGrid('products-grid');
}

function cartLoad(){ 
  try{ return JSON.parse(localStorage.getItem('demo_cart')||'[]') } catch(e){return[]}
}
function cartSave(c){ localStorage.setItem('demo_cart', JSON.stringify(c)) }
function cartCount(){ return cartLoad().reduce((s,i)=>s+i.qty,0) }

function addToCart(id){
  const cart = cartLoad();
  const p = PRODUCTS.find(x=>x.id===id);
  if(!p) return;
  const found = cart.find(x=>x.id===id);
  if(found) found.qty++;
  else cart.push({id:id,qty:1,title:p.title,price:p.price});
  cartSave(cart);
  updateCartUI();
}

function updateCartUI(){
  el('#cart-count').textContent = cartCount();
}

function openCart(){
  const modal = el('#cart-modal');
  modal.setAttribute('aria-hidden','false');
  renderCartItems();
}

function closeCart(){
  const modal = el('#cart-modal');
  modal.setAttribute('aria-hidden','true');
}

function renderCartItems(){
  const container = el('#cart-items');
  const cart = cartLoad();
  container.innerHTML = '';
  let total = 0;
  for(const item of cart){
    total += item.price * item.qty;
    const div = document.createElement('div');
    div.className = 'cart-item';
    div.innerHTML = `<img src="images/p_thumb.svg" alt=""><div><strong>${item.title}</strong><div>${item.qty} × ${item.price.toFixed(2)} грн</div></div>`;
    container.appendChild(div);
  }
  el('#cart-total').textContent = total.toFixed(2);
  updateCartUI();
}

// Event delegation
document.addEventListener('click', function(e){
  if(e.target.matches('.add-btn')){
    const id = Number(e.target.dataset.id);
    addToCart(id);
  } else if(e.target.id === 'cart-btn'){
    openCart();
  } else if(e.target.id === 'close-cart'){
    closeCart();
  }
});

// Init
document.addEventListener('DOMContentLoaded', function(){
  populatePreview();
  updateCartUI();
});
